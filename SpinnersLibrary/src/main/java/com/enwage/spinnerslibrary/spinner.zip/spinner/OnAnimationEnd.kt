package com.enwage.spinnerslibrary.spinner

public interface OnAnimationEnd {
    public abstract fun onAnimationEndListener(isRevealed: kotlin.Boolean): kotlin.Unit
}

