package com.enwage.spinnerslibrary.spinner

//data class SearchableItem(val id: Int, val text: String) {
//    var isSelected: Boolean = false
//}
