package com.enwage.spinnerslibrary.spinner


public interface OnItemSelectListener {
    public abstract fun setOnItemSelectListener(position: kotlin.Int, selectedString: kotlin.String): kotlin.Unit
}